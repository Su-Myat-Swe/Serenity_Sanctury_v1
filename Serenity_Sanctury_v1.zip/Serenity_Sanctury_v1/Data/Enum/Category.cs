﻿namespace Serenity_Sanctury_v1.Data.Enum
{
    public enum Category
    {
        Candles,
        EssentialOil,
        AromaDiffuser
    }
}

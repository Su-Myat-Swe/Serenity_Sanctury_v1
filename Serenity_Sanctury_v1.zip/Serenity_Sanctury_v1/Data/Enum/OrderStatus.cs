﻿namespace Serenity_Sanctury_v1.Data.Enum
{
    // defined the Order Status enum separately
    public enum OrderStatus
    {
        Pending,
        Shipped,
        Delivered,
        Cancelled
    }
}

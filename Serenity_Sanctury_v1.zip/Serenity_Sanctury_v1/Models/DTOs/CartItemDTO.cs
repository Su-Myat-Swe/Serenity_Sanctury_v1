﻿namespace Serenity_Sanctury_v1.Models
{
    public class CartItemDTO
    {
        public int ProductID { get; set; }
        public int Quantity { get; set; }
    }
}
